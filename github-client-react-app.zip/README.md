# github-client

Github client app built using ReactJS + Redux

To run the application on local machine:
npm/yarn install
npm/yarn start

