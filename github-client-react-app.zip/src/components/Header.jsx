import React from "react";

const Header = () => (
    <div className="row">
        <div className="col-md-12">
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                <span className="navbar-brand">Github Client</span>
            </nav>
        </div>        
      </div>
)

 export default Header;